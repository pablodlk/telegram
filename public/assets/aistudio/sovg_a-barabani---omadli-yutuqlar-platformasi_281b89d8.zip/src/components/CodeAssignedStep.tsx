import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  Sparkles,
  Copy,
  Check,
  Send,
  PhoneCall,
  ExternalLink,
  ShieldCheck,
  User,
  Phone,
  Ticket,
  CheckCircle,
} from 'lucide-react';
import { PrizeIcon } from './PrizeIcon.js';

interface CodeAssignedStepProps {
  participantName: string;
  phone?: string;
  specialCode: string;
  assignedPrize: {
    id: string;
    name: string;
    description?: string;
    icon?: string;
    color?: string;
  };
  telegramUrl: string;
  operatorPhone?: string;
  operatorTelegram?: string;
}

export const CodeAssignedStep: React.FC<CodeAssignedStepProps> = ({
  participantName,
  phone,
  specialCode,
  assignedPrize,
  telegramUrl,
  operatorPhone = '+998 93 799 04 23',
  operatorTelegram = '@omadli_operator',
}) => {
  const [copied, setCopied] = useState(false);

  // Festive confetti blast on page load
  useEffect(() => {
    const duration = 3.5 * 1000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 5,
        angle: 60,
        spread: 60,
        origin: { x: 0 },
        colors: ['#D4AF37', '#F59E0B', '#10B981', '#38BDF8', '#FFFFFF'],
      });
      confetti({
        particleCount: 5,
        angle: 120,
        spread: 60,
        origin: { x: 1 },
        colors: ['#D4AF37', '#F59E0B', '#10B981', '#38BDF8', '#FFFFFF'],
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();
  }, []);

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(specialCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (e) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const cleanOperatorTelegram = operatorTelegram.startsWith('http')
    ? operatorTelegram
    : `https://t.me/${operatorTelegram.replace('@', '')}`;

  const cleanTelegramUrl = telegramUrl.startsWith('http')
    ? telegramUrl
    : `https://t.me/${telegramUrl.replace('@', '')}`;

  const cleanPhoneHref = `tel:${operatorPhone.replace(/\s+/g, '')}`;

  return (
    <div className="w-full max-w-lg mx-auto py-4 sm:py-6 px-4 flex flex-col items-center animate-fadeIn text-center">
      {/* Golden Badge */}
      <div className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-amber-500/15 border border-amber-400/40 text-amber-300 text-xs font-black tracking-wider uppercase mb-3 shadow-lg shadow-amber-500/10">
        <Sparkles className="w-4 h-4 text-amber-400 animate-spin" style={{ animationDuration: '4s' }} />
        <span>G‘OLIB ISHTIROKCHI</span>
      </div>

      {/* Main Congratulation Heading Required by User */}
      <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 font-serif tracking-tight mb-2">
        Tabriklaymiz, siz 3-ishtirokchi sifatida tanlab olindingiz!
      </h1>

      <div className="inline-flex items-center gap-2 text-xs sm:text-sm text-slate-300 font-medium mb-5 bg-slate-900/60 px-4 py-1.5 rounded-full border border-slate-800">
        <User className="w-3.5 h-3.5 text-amber-400" />
        <span className="font-semibold text-white">{participantName}</span>
        {phone && (
          <>
            <span className="text-slate-600">•</span>
            <Phone className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-300 font-mono">{phone}</span>
          </>
        )}
      </div>

      {/* Special Code Box Card */}
      <div className="w-full bg-gradient-to-b from-[#0F1C3F] to-[#0A122A] border-2 border-amber-400/50 rounded-3xl p-6 sm:p-7 shadow-2xl relative overflow-hidden mb-5">
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-amber-500/20 rounded-full blur-2xl pointer-events-none" />

        <div className="text-xs uppercase font-bold text-amber-400/90 tracking-wider mb-2">
          🎟️ Sizning maxsus kodingiz:
        </div>

        {/* Special Code Box with Copy */}
        <div className="bg-[#060A17] border border-amber-500/30 rounded-2xl p-4 sm:p-5 text-center shadow-inner">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>MAXSUS ISHTIROKCHI KODI:</span>
          </div>

          <div className="flex items-center justify-center gap-3">
            <span className="font-mono text-2xl sm:text-3xl font-black tracking-widest text-amber-300 select-all">
              {specialCode}
            </span>
            <button
              onClick={handleCopyCode}
              className={`p-2.5 rounded-xl border transition-all flex items-center gap-1.5 text-xs font-bold cursor-pointer ${
                copied
                  ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                  : 'bg-amber-500/20 border-amber-400/40 text-amber-200 hover:bg-amber-500/30'
              }`}
              title="Kodni nusxalash"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="hidden sm:inline">Nusxalandi</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span className="hidden sm:inline">Nusxalash</span>
                </>
              )}
            </button>
          </div>

          <div className="mt-3 pt-3 border-t border-amber-500/20 text-[11px] text-amber-200/90 flex flex-col gap-0.5 text-center">
            <span className="font-semibold">⚡ Ushbu maxsus kodni operatorga taqdim etasiz!</span>
          </div>
        </div>
      </div>

      {/* Operator Contact Callout - Prominent for getting detailed information and claiming */}
      <div className="w-full bg-gradient-to-r from-emerald-950/80 via-emerald-900/40 to-emerald-950/80 border-2 border-emerald-500/60 rounded-3xl p-5 sm:p-6 mb-5 text-left shadow-xl">
        <div className="flex items-start gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
            <PhoneCall className="w-5 h-5 text-emerald-400 animate-pulse" />
          </div>
          <div>
            <h3 className="text-base sm:text-lg font-black text-emerald-200">
              Batafsil ma’lumot olish va sovg‘ani qabul qilish uchun operator bilan bog‘laning!
            </h3>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              Operatorimizga o‘zingizning maxsus kodingiz (<span className="font-mono font-bold text-amber-300">{specialCode}</span>)ni taqdim etib, batafsil ma’lumot olasiz.
            </p>
          </div>
        </div>

        {/* Action Buttons to Call Operator */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 border-t border-emerald-500/20">
          <a
            href={cleanPhoneHref}
            className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-slate-950 font-black text-sm uppercase tracking-wide flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
          >
            <PhoneCall className="w-4 h-4 text-slate-950" />
            <span>Operatorga Qo‘ng‘iroq ({operatorPhone})</span>
          </a>

          <a
            href={cleanOperatorTelegram}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs uppercase tracking-wide flex items-center justify-center gap-2 shadow-lg shadow-sky-600/25 transition-all cursor-pointer"
          >
            <Send className="w-4 h-4 text-white" />
            <span>Telegram Operator ({operatorTelegram})</span>
            <ExternalLink className="w-3.5 h-3.5 text-sky-200" />
          </a>
        </div>
      </div>

      {/* Telegram Channel Link */}
      <div className="w-full max-w-md">
        <a
          href={cleanTelegramUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="w-full py-3 px-4 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold flex items-center justify-center gap-2 border border-slate-800 transition-all cursor-pointer"
        >
          <Send className="w-4 h-4 text-sky-400" />
          <span>Rasmiy Telegram Kanalimiz</span>
          <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
        </a>
      </div>
    </div>
  );
};
